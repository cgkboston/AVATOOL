﻿#region PROJECT_HEADER
//   PROJECT: AVATOOL
//  FILENAME: AVATOOL.cs
//   VERSION: 0.5.0-beta
//     BUILD: 200811
//   AUTHORS: cgk@aprettycoolprogram.com
// COPYRIGHT: 2020 A Pretty Cool Program
// LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport, cgkboston@github
#endregion

#region CLASS_DESCRIPTION
/*  Contains all of the logic for working with the WEBSVC.UserManagement Web Service. */
#endregion

#region USING
using System;
using System.ServiceModel;
using AVATOOL.UserManagement;
#endregion

namespace AVATOOL
{
    class Program
    {
        static void Main(String[] args)
        {
            String AvatarEnv = "LIVE";
            Boolean UserExistsP = false;
            String HelpDeskUser = "HELPDESK";
            String HelpDeskPassword = "V4NH4L3N";
            String userid = "";
            // The user name token appears to be any number you want, ..., I went with token 12.
            // Mainly because, that's what NTST jslatterley@ntst.com sent me.
            String UserSecurityToken = "UsernameToken - 250";
            if (args.Length == 0)
            {
                Console.Write("Enter Avatar UserID: ");
                userid = Console.ReadLine();
                userid = userid.ToUpper();
            }
            else
            {
                userid = args[0].ToUpper();
            }
            if (String.IsNullOrEmpty(userid))
            {
                Console.WriteLine("Try again...");
                Console.ReadKey();
            }
            else { 
                Console.WriteLine("Call DoesUserExist for User: " + userid);
                UserExistsP = DoesUserExist(AvatarEnv, HelpDeskUser, HelpDeskPassword, 
                    UserSecurityToken, userid);
                if (UserExistsP == true)
                {
                    Console.WriteLine("User: " + userid + " Exists.");
                    // User Exists, ergo reset the user password.
                    GeneratePassword(AvatarEnv, HelpDeskUser, HelpDeskPassword, 
                        UserSecurityToken, userid);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("User: " + userid + " Does NOT Exist...Press Enter to Exit and try again.");
                    Console.ReadKey();
                }
            }
        }

        // The UserSecurityToken is required for the enhanced wss web services security.
        // WSSE is a CACHE 2017 requirement.
        private static Boolean DoesUserExist(String AvatarEnv, String HelpDeskUser, 
            String HelpDeskPassword, String UserSecurityToken, String userid)
        {
            WebServicesSoapClient client = new WebServicesSoapClient();
            AVATOOL.UserManagement.WebServiceResponse resp;
            UserDefinitionObject userObject = new UserDefinitionObject();
            userObject.UserId = userid;
            userObject.IsUserAStaffMember = "Y";
            userObject.PasswordTermDurationDays = 90;
            userObject.ReminderNoticeNumDays = 7;

            Console.WriteLine("In DoesUserExist for User: " + userObject.UserId);
            using (new OperationContextScope(client.InnerChannel))
            {
                OperationContext.Current.OutgoingMessageHeaders.Add(new SecurityHeader(
                    UserSecurityToken, AvatarEnv+":"+HelpDeskUser, HelpDeskPassword));
                resp = client.DoesUserExist(AvatarEnv, HelpDeskUser, HelpDeskPassword, 
                        userObject.UserId);
            }
            return (resp.Message.Contains("User - "+userObject.UserId+" - does exist."));
        }

        // The UserSecurityToken is required for the enhanced wss web services security.
        // WSSE is a CACHE 2017 requirement.
        private static void GeneratePassword(String AvatarEnv, String HelpDeskUser, 
            String HelpDeskPassword, String UserSecurityToken, String userid)
        {
            WebServicesSoapClient client = new WebServicesSoapClient();
            AVATOOL.UserManagement.WebServiceResponse resp;
            UserDefinitionObject userObject = new UserDefinitionObject();
            userObject.UserId = userid;
            userObject.IsUserAStaffMember = "Y";
            userObject.PasswordTermDurationDays = 90;
            userObject.ReminderNoticeNumDays = 7;

            Console.WriteLine("In GeneratePassword for User: " + userObject.UserId);
            using (new OperationContextScope(client.InnerChannel))
            {
                OperationContext.Current.OutgoingMessageHeaders.Add(new SecurityHeader(
                    UserSecurityToken, AvatarEnv+":"+HelpDeskUser, HelpDeskPassword));
                resp = client.GeneratePassword(AvatarEnv, HelpDeskUser, HelpDeskPassword, 
                    userObject.UserId);
            }
            Console.WriteLine("TEMPORARY passord for "+userObject.UserId + " is: " + 
                resp.Message);
            return;
        }
    }
}
