﻿#region PROJECT_HEADER
// PROJECT: AVATOOL
// FILENAME: AVATOOL.cs
// VERSION: 0.5.0-beta
// BUILD: 200814
// AUTHORS: cgk@aprettycoolprogram.com
// COPYRIGHT: 2020 A Pretty Cool Program
// LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport,..., not or https://github.com 
// user: cgkboston@github
#endregion

#region CLASS_DESCRIPTION
//  Contains all of the logic for working with the WEBSVC.UserManagement Web Service.
//  Update 1: 8/13/2020 prompt the help desk user to enter the help desk password
//  Update 2: 8/14/2020 Mask the Help desk user's reponse.
#endregion

#region USING
using System;
using System.ServiceModel;
using AVATOOL.UserManagement;
#endregion

namespace AVATOOL
{
    class Program
    {
        static void Main(String[] args)
        {
            String AvatarEnv = "LIVE";
            Boolean UserExistsP = false;
            String HelpDeskUser = "HELPDESK";
            String HelpDeskPassword = "";
            String userid = "";

            // The user name token appears to be any number you want, ..., I went with token 12.
            // Mainly because, that's what NTST jslatterley@ntst.com sent me.
            String UserSecurityToken = "UsernameToken - 250";

            if (args.Length == 0)
            {
                Console.Write("Enter Avatar UserID: ");
                userid = Console.ReadLine();
                userid = userid.ToUpper();
            }
            else
            {
                userid = args[0].ToUpper();
            }
            if (String.IsNullOrEmpty(userid))
            {
                Console.WriteLine("Try again...");
                Console.ReadKey();
            }
            else if (args.Length < 2)
            {
                Console.Write("Enter HELPDESK Password: ");
                HelpDeskPassword = ReadHelpDeskPassword();
                if (String.IsNullOrEmpty(HelpDeskPassword))
                {
                    Console.WriteLine("Try again...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Call DoesUserExist for User: " + userid);
                    UserExistsP = DoesUserExist(AvatarEnv, HelpDeskUser, HelpDeskPassword,
                        UserSecurityToken, userid);
                    if (UserExistsP == true)
                    {
                        Console.WriteLine("User: " + userid + " Exists.");
                        // User Exists, ergo reset the user password.
                        GeneratePassword(AvatarEnv, HelpDeskUser, HelpDeskPassword,
                            UserSecurityToken, userid);
                    }
                    else
                    {
                        Console.WriteLine("User: " + userid + " Does NOT Exist...Press Enter to Exit and try again.");
                        Console.ReadKey();
                    }
                }
            }
            else
            {
                Console.WriteLine("Usage: " +  "AVATOOL.exe " + "&optional AVATAR User Id...Press Enter to Exit and try again.");
                Console.ReadKey();
            }
        }

        // The UserSecurityToken is required for the enhanced wss web services security.
        // WSSE is a CACHE 2017 requirement.

        private static Boolean DoesUserExist(String AvatarEnv, String HelpDeskUser,
            String HelpDeskPassword, String UserSecurityToken, String userid)
        {
            WebServicesSoapClient client = new WebServicesSoapClient();
            AVATOOL.UserManagement.WebServiceResponse resp;
            UserDefinitionObject userObject = new UserDefinitionObject();
            userObject.UserId = userid;
            userObject.IsUserAStaffMember = "Y";
            userObject.PasswordTermDurationDays = 90;
            userObject.ReminderNoticeNumDays = 7;

            using (new OperationContextScope(client.InnerChannel))
            {
                Console.WriteLine("Generating Outgoing Message Security Header ... for HELPDESK User");
                OperationContext.Current.OutgoingMessageHeaders.Add(new SecurityHeader(
                    UserSecurityToken, AvatarEnv + ":" + HelpDeskUser, HelpDeskPassword));
                resp = client.DoesUserExist(AvatarEnv, HelpDeskUser, HelpDeskPassword,
                        userObject.UserId);
            }
            return (resp.Message.Contains("User - " + userObject.UserId + " - does exist."));
        }

        // The UserSecurityToken is required for the enhanced wss web services security.
        // WSSE is a CACHE 2017 requirement.

        private static void GeneratePassword(String AvatarEnv, String HelpDeskUser,
            String HelpDeskPassword, String UserSecurityToken, String userid)
        {
            WebServicesSoapClient client = new WebServicesSoapClient();
            AVATOOL.UserManagement.WebServiceResponse resp;
            UserDefinitionObject userObject = new UserDefinitionObject();
            userObject.UserId = userid;
            userObject.IsUserAStaffMember = "Y";
            userObject.PasswordTermDurationDays = 90;
            userObject.ReminderNoticeNumDays = 7;

            Console.WriteLine("GeneratePassword for User: " + userObject.UserId);
            using (new OperationContextScope(client.InnerChannel))
            {
                OperationContext.Current.OutgoingMessageHeaders.Add(new SecurityHeader(
                    UserSecurityToken, AvatarEnv + ":" + HelpDeskUser, HelpDeskPassword));
                resp = client.GeneratePassword(AvatarEnv, HelpDeskUser, HelpDeskPassword,
                    userObject.UserId);
            }
            Console.WriteLine("TEMPORARY passord for " + userObject.UserId + " is: " +
                resp.Message);
            Console.ReadKey();
            return;
        }

	// The ReadHelpDeskPassword method masks the Help Desk User's password response. 

        public static string ReadHelpDeskPassword()
        {
            string password = "";
            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);
                switch (key.Key)
                {
                    case ConsoleKey.Escape:
                        return null;
                    case ConsoleKey.Enter:
                        Console.Write("\n");
                        return password;
                    case ConsoleKey.Backspace:
                        if (password.Length > 0)
                        {
                            password = password.Substring(0, (password.Length - 1));
                            Console.Write("\b \b");
                        }
                        break;
                    default:
                        password += key.KeyChar;
                        Console.Write("*");
                        break;
                }
            }
        }
    }
}
